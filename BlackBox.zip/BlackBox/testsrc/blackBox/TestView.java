package blackBox;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit test for the View class.
 * 
 * @author noah
 */
class TestView implements ViewListener {
  private View view;

  /**
   * Create the view which creates the game board.
   * 
   * @throws Exception setup failed
   */
  @BeforeEach
  void setUp() throws Exception {
    view = new View(this);
  }

  /**
   * Close and dispose of the view.
   * 
   * @throws Exception tear down failed
   */
  @AfterEach
  void tearDown() throws Exception {
    view.close();
    view = null;
    System.gc();
  }

  /**
   * Set each atom button to true to display it. Then set to default to clear
   * them all.
   */
  @Test
  void testGridAtoms() {
    try {
      Thread.sleep(250);
      view.setAtom(new Position(0, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(0, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(1, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(2, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(3, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(4, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(5, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(6, 7), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 0), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 1), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 2), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 3), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 4), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 5), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 6), true);
      Thread.sleep(250);
      view.setAtom(new Position(7, 7), true);
      Thread.sleep(250);
      view.setAtomDefault();
      Thread.sleep(250);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Set each ray button to a rotation number and color. Then set to default to
   * clear them all.
   */
  @Test
  void testRays() {
    int cnt = 1;
    try {
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 0), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 1), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 2), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 3), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 4), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 5), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 6), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.NORTH, 7), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 0), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 1), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 2), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 3), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 4), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 5), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 6), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.SOUTH, 7), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setAtomDefault();
      view.setRayData(new Position(Direction.EAST, 0), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 1), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 2), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 3), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 4), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 5), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 6), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.EAST, 7), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 0), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 1), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 2), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 3), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 4), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 5), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 6), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayData(new Position(Direction.WEST, 7), cnt++,
          view.getNextColor());
      Thread.sleep(250);
      view.setRayDefault();
      Thread.sleep(250);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Does nothing.
   */
  @Override
  public void rayButton(Position pos, int number) {
  }

  /**
   * Does nothing.
   */
  @Override
  public void atomButton(Position pos, boolean atomState) {
  }

  /**
   * Does nothing.
   */
  @Override
  public void quit() {
  }

  /**
   * Does nothing.
   */
  @Override
  public void newGame() {
  }

  /**
   * Does nothing.
   */
  @Override
  public void solve() {
  }
}