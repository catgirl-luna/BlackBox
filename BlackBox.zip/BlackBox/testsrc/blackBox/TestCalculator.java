package blackBox;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import java.util.ArrayList;
import java.util.Iterator;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit test for the Calculator class. It uses the move patterns from the
 * Parker Brothers game manual for the tests. The moves 10 and 11 are left out
 * because they are duplicates.
 * 
 * @author noah
 */
class TestCalculator {
  // Use the FauxCalculator to test the test program. Replace with the
  // Calculator for real testing.
  private Calculator calculator;
  private Position pos;

  // Defines the hit and reflection positions for comparisons.
  private Position hitPos = new Position(-1, -1);
  private Position rfltPos = new Position(-2, -2);

  // Defines the four corners for the reflection edge cases.
  private Position NWPos = new Position(0, 0);
  private Position NEPos = new Position(7, 0);
  private Position SWPos = new Position(0, 7);
  private Position SEPos = new Position(7, 7);

  /**
   * Create the calculator before each test.
   * 
   * @throws Exception setup failed
   */
  @BeforeEach
  void setUp() throws Exception {
    calculator = new Calculator();
  }

  /**
   * Destroy the calculator after each test.
   * 
   * @throws Exception tear down failed
   */
  @AfterEach
  void tearDown() throws Exception {
    calculator = null;
    System.gc();
  }

  /**
   * Test the atom creations for 100 iterations. It looks for the proper number
   * of atoms, X and Y range and no duplicate positions.
   */
  @SuppressWarnings ("null")
  @Test
  void testCreateAtoms() {
    ArrayList <Position> plist;
    ArrayList <Position> list = null;
    Position p;
    int count = 0;
    while (count++ < 100) {
      plist = new ArrayList <Position>();
      try {
        list = calculator.createAtoms();
      } catch (Exception e) {
        fail("Creating atoms failed; " + e.getMessage());
      }
      assertEquals(4, list.size());
      Iterator <Position> listItr = list.iterator();
      Iterator <Position> plistItr;
      while (listItr.hasNext()) {
        p = listItr.next();
        if ( (p.x < 0) || (p.x > 7) || (p.y < 0) || (p.y > 7)) {
          fail("Position outside of range: " + p);
        }
        plistItr = plist.iterator();
        while (plistItr.hasNext()) {
          if (plistItr.next().equals(p)) {
            fail("Found duplicate position");
          }
        }
        plist.add(p);
      }
    }
  }

  /**
   * Test ray placement on hit boundary.
   */
  @Test
  void testCalculateRays1() {
    Position[] atoms = {
        new Position(0, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 2.
   */
  @Test
  void testCalculateRays2() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 2 edge case.
   */
  @Test
  void testCalculateRays2A() {
    Position[] atoms = {
        new Position(4, 7)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 3.
   */
  @Test
  void testCalculateRays3() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 3 edge case.
   */
  @Test
  void testCalculateRays3A() {
    Position[] atoms = {
        new Position(0, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 4.
   */
  @Test
  void testCalculateRays4() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 4 edge case.
   */
  @Test
  void testCalculateRays4A() {
    Position[] atoms = {
        new Position(4, 0)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 5.
   */
  @Test
  void testCalculateRays5() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
    Position[] atoms2 = {
        new Position(7, 3)
    };
    calculator.setAtoms(atoms2);
    pos = new Position(Direction.EAST, 3);
    ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 5 edge case.
   */
  @Test
  void testCalculateRays5A() {
    Position[] atoms = {
        new Position(7, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 6.
   */
  @Test
  void testCalculateRays6() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.WEST, 4), ray[1]);
  }

  /**
   * Test ray placement using manual's move 6.
   */
  @Test
  void testCalculateRays6A() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.SOUTH, 3), ray[1]);
  }

  /**
   * Test ray placement using manual's move 7.
   */
  @Test
  void testCalculateRays7() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 3);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.WEST, 2), ray[1]);
  }

  /**
   * Test ray placement using manual's move 7.
   */
  @Test
  void testCalculateRays7A() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 2);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.NORTH, 3), ray[1]);
  }

  /**
   * Test ray placement using manual's move 8.
   */
  @Test
  void testCalculateRays8() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.EAST, 2), ray[1]);
  }

  /**
   * Test ray placement using manual's move 8.
   */
  @Test
  void testCalculateRays8A() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 2);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.NORTH, 5), ray[1]);
  }

  /**
   * Test ray placement using manual's move 9.
   */
  @Test
  void testCalculateRays9() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.EAST, 4), ray[1]);
  }

  /**
   * Test ray placement using manual's move 9.
   */
  @Test
  void testCalculateRays9A() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.SOUTH, 5), ray[1]);
  }

  /**
   * Test ray placement using manual's move 12.
   */
  @Test
  void testCalculateRays12() {
    Position[] atoms = {
        new Position(6, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.WEST, 4), ray[1]);
  }

  /**
   * Test ray placement using manual's move 13.
   */
  @Test
  void testCalculateRays13() {
    Position[] atoms = {
        new Position(4, 7)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 13 north-west corner cases.
   */
  @Test
  void testCalculateRays13A() {
    Position[] atoms = {
        NWPos
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 1);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
    pos = new Position(Direction.WEST, 1);
    ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 13 north-east corner cases.
   */
  @Test
  void testCalculateRays13B() {
    Position[] atoms = {
        NEPos
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 6);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
    pos = new Position(Direction.EAST, 1);
    ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 13 south-west corner cases.
   */
  @Test
  void testCalculateRays13C() {
    Position[] atoms = {
        SWPos
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 1);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
    pos = new Position(Direction.WEST, 6);
    ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 13 south-east corner cases.
   */
  @Test
  void testCalculateRays13D() {
    Position[] atoms = {
        SEPos
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 6);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
    pos = new Position(Direction.EAST, 6);
    ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 14.
   */
  @Test
  void testCalculateRays14() {
    Position[] atoms = {
        new Position(4, 3), new Position(6, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 14.
   */
  @Test
  void testCalculateRays14A() {
    Position[] atoms = {
        new Position(4, 3), new Position(6, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 14.
   */
  @Test
  void testCalculateRays14B() {
    Position[] atoms = {
        new Position(4, 3), new Position(4, 5)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 14.
   */
  @Test
  void testCalculateRays14C() {
    Position[] atoms = {
        new Position(4, 3), new Position(4, 5)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 15.
   */
  @Test
  void testCalculateRays15() {
    Position[] atoms = {
        new Position(4, 3), new Position(7, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.SOUTH, 6), ray[1]);
  }

  /**
   * Test ray placement using manual's move 16.
   */
  @Test
  void testCalculateRays16() {
    Position[] atoms = {
        new Position(5, 7)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 17.
   */
  @Test
  void testCalculateRays17() {
    Position[] atoms = {
        new Position(5, 6)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.WEST, 7), ray[1]);
  }

  /**
   * Test ray placement using manual's move 17 right detour.
   */
  @Test
  void testCalculateRays17A() {
    Position[] atoms = {
        new Position(5, 6)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 6);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.EAST, 7), ray[1]);
  }

  /**
   * Test ray placement using manual's move 18.
   */
  @Test
  void testCalculateRays18() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 2);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.NORTH, 2), ray[1]);
  }

  /**
   * Test ray placement using manual's move 19.
   */
  @Test
  void testCalculateRays19() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.WEST, 1);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.EAST, 1), ray[1]);
  }

  /**
   * Test ray placement using manual's move 20.
   */
  @Test
  void testCalculateRays20() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 6);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.SOUTH, 6), ray[1]);
  }

  /**
   * Test ray placement using manual's move 21.
   */
  @Test
  void testCalculateRays21() {
    Position[] atoms = {
        new Position(4, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.WEST, 5), ray[1]);
  }

  /**
   * Test ray placement using manual's move 22.
   */
  @Test
  void testCalculateRays22() {
    Position[] atoms = {
        new Position(4, 3), new Position(5, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 23.
   */
  @Test
  void testCalculateRays23() {
    Position[] atoms = {
        new Position(4, 3), new Position(5, 4)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.WEST, 5), ray[1]);
  }

  /**
   * Test ray placement using manual's move 24.
   */
  @Test
  void testCalculateRays24() {
    Position[] atoms = {
        new Position(4, 3), new Position(5, 3), new Position(6, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 25.
   */
  @Test
  void testCalculateRays25() {
    Position[] atoms = {
        new Position(4, 3), new Position(5, 2), new Position(6, 3)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 5);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 26.
   */
  @Test
  void testCalculateRays26() {
    Position[] atoms = {
        new Position(4, 0), new Position(0, 2), new Position(4, 4)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.NORTH, 1);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(new Position(Direction.SOUTH, 1), ray[1]);
  }

  /**
   * Test ray placement using manual's move 27.
   */
  @Test
  void testCalculateRays27() {
    Position[] atoms = {
        new Position(4, 0), new Position(4, 4), new Position(6, 4)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.EAST, 1);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 28.
   */
  @Test
  void testCalculateRays28() {
    Position[] atoms = {
        new Position(0, 2), new Position(7, 2), new Position(5, 5),
        new Position(6, 5), new Position(0, 7)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 4);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(hitPos, ray[1]);
  }

  /**
   * Test ray placement using manual's move 29.
   */
  @Test
  void testCalculateRays29() {
    Position[] atoms = {
        new Position(0, 0), new Position(6, 0), new Position(6, 2),
        new Position(0, 4), new Position(6, 6)
    };
    calculator.setAtoms(atoms);
    pos = new Position(Direction.SOUTH, 1);
    Position[] ray = calculator.calculateRays(pos);
    assertEquals(2, ray.length);
    assertEquals(pos, ray[0]);
    assertEquals(rfltPos, ray[1]);
  }
}
