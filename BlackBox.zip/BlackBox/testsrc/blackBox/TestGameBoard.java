package blackBox;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.awt.Component;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * JUnit test for the GameBoard class. It checks the menu items and grid
 * buttons.
 * 
 * @author noah
 */
class TestGameBoard implements GameBoardListener {

  private GameBoard board;
  /**
   * 
   */
  Iterator <Position> posIterator;
  private String menuName;

  /**
   * Create the game board and position list.
   * 
   * @throws Exception setup failed
   */
  @BeforeEach
  void setUp() throws Exception {
    // Set the grid positions for comparing with the button presses.
    ArrayList <Position> posList = new ArrayList <Position>();
    posList.add(new Position(Direction.NORTH, 0));
    posList.add(new Position(Direction.NORTH, 1));
    posList.add(new Position(Direction.NORTH, 2));
    posList.add(new Position(Direction.NORTH, 3));
    posList.add(new Position(Direction.NORTH, 4));
    posList.add(new Position(Direction.NORTH, 5));
    posList.add(new Position(Direction.NORTH, 6));
    posList.add(new Position(Direction.NORTH, 7));
    posList.add(new Position(Direction.WEST, 0));
    posList.add(new Position(0, 0));
    posList.add(new Position(1, 0));
    posList.add(new Position(2, 0));
    posList.add(new Position(3, 0));
    posList.add(new Position(4, 0));
    posList.add(new Position(5, 0));
    posList.add(new Position(6, 0));
    posList.add(new Position(7, 0));
    posList.add(new Position(Direction.EAST, 0));
    posList.add(new Position(Direction.WEST, 1));
    posList.add(new Position(0, 1));
    posList.add(new Position(1, 1));
    posList.add(new Position(2, 1));
    posList.add(new Position(3, 1));
    posList.add(new Position(4, 1));
    posList.add(new Position(5, 1));
    posList.add(new Position(6, 1));
    posList.add(new Position(7, 1));
    posList.add(new Position(Direction.EAST, 1));
    posList.add(new Position(Direction.WEST, 2));
    posList.add(new Position(0, 2));
    posList.add(new Position(1, 2));
    posList.add(new Position(2, 2));
    posList.add(new Position(3, 2));
    posList.add(new Position(4, 2));
    posList.add(new Position(5, 2));
    posList.add(new Position(6, 2));
    posList.add(new Position(7, 2));
    posList.add(new Position(Direction.EAST, 2));
    posList.add(new Position(Direction.WEST, 3));
    posList.add(new Position(0, 3));
    posList.add(new Position(1, 3));
    posList.add(new Position(2, 3));
    posList.add(new Position(3, 3));
    posList.add(new Position(4, 3));
    posList.add(new Position(5, 3));
    posList.add(new Position(6, 3));
    posList.add(new Position(7, 3));
    posList.add(new Position(Direction.EAST, 3));
    posList.add(new Position(Direction.WEST, 4));
    posList.add(new Position(0, 4));
    posList.add(new Position(1, 4));
    posList.add(new Position(2, 4));
    posList.add(new Position(3, 4));
    posList.add(new Position(4, 4));
    posList.add(new Position(5, 4));
    posList.add(new Position(6, 4));
    posList.add(new Position(7, 4));
    posList.add(new Position(Direction.EAST, 4));
    posList.add(new Position(Direction.WEST, 5));
    posList.add(new Position(0, 5));
    posList.add(new Position(1, 5));
    posList.add(new Position(2, 5));
    posList.add(new Position(3, 5));
    posList.add(new Position(4, 5));
    posList.add(new Position(5, 5));
    posList.add(new Position(6, 5));
    posList.add(new Position(7, 5));
    posList.add(new Position(Direction.EAST, 5));
    posList.add(new Position(Direction.WEST, 6));
    posList.add(new Position(0, 6));
    posList.add(new Position(1, 6));
    posList.add(new Position(2, 6));
    posList.add(new Position(3, 6));
    posList.add(new Position(4, 6));
    posList.add(new Position(5, 6));
    posList.add(new Position(6, 6));
    posList.add(new Position(7, 6));
    posList.add(new Position(Direction.EAST, 6));
    posList.add(new Position(Direction.WEST, 7));
    posList.add(new Position(0, 7));
    posList.add(new Position(1, 7));
    posList.add(new Position(2, 7));
    posList.add(new Position(3, 7));
    posList.add(new Position(4, 7));
    posList.add(new Position(5, 7));
    posList.add(new Position(6, 7));
    posList.add(new Position(7, 7));
    posList.add(new Position(Direction.EAST, 7));
    posList.add(new Position(Direction.SOUTH, 0));
    posList.add(new Position(Direction.SOUTH, 1));
    posList.add(new Position(Direction.SOUTH, 2));
    posList.add(new Position(Direction.SOUTH, 3));
    posList.add(new Position(Direction.SOUTH, 4));
    posList.add(new Position(Direction.SOUTH, 5));
    posList.add(new Position(Direction.SOUTH, 6));
    posList.add(new Position(Direction.SOUTH, 7));
    posIterator = posList.listIterator();

    // Create the game board.
    java.awt.EventQueue.invokeLater(() -> {
      board = new GameBoard(this);
    });
    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      e.printStackTrace();
    }
  }

  /**
   * Disposes of the game board instance.
   * 
   * @throws Exception tear down failed
   */
  @AfterEach
  void tearDown() throws Exception {
    board.setVisible(false);
    board.dispose();
    posIterator = null;
    System.gc();
  }

  /**
   * Test the game board grid buttons.
   */
  @SuppressWarnings ("null")
  @Test
  void testGameBoard() {
    // Get the main panel inside the frame.
    Component[] comps = board.getContentPane().getComponents();
    JPanel jPanel = null;
    for (int i = 0; i < comps.length; i++) {
      if (comps[i] instanceof JPanel) {
        jPanel = (JPanel) comps[i];
        break;
      }
    }

    // Get the grid panel inside the main panel.
    comps = jPanel.getComponents();
    JPanel panel;
    for (int i = 0; i < comps.length; i++) {
      if (comps[i] instanceof JPanel) {
        panel = (JPanel) comps[i];
        if (panel.getLayout() instanceof java.awt.GridBagLayout) {
          // Save the grid panel.
          jPanel = panel;
        }
      }
    }

    // Add the grid buttons to the list.
    ArrayList <ButtonData> buttonList = new ArrayList <ButtonData>();
    comps = jPanel.getComponents();
    for (int i = 0; i < comps.length; i++) {
      if (comps[i] instanceof JButton) {
        buttonList.add(new ButtonData((JButton) comps[i]));
      }
    }

    // Sort the grid buttons into position order.
    Collections.sort(buttonList);

    // Click each button in order.
    JButton button;
    for (ButtonData data : buttonList) {
      button = data.button;
      button.doClick();
    }
  }

  /**
   * Tests the menu items by finding the buttons in the components and clicking
   * them programmatically.
   */
  @Test
  void testMenu() {
    Component[] comps = board.getJMenuBar().getComponents();
    Component[] mComps;
    JMenuItem menuItem;
    for (int i = 0; i < comps.length; i++) {
      if (comps[i] instanceof JMenu) {
        mComps = ((JMenu) comps[i]).getMenuComponents();
        for (int j = 0; j < mComps.length; j++) {
          menuItem = (JMenuItem) mComps[j];
          switch (menuItem.getText()) {
            case "New Game":
              menuName = "newGame";
              menuItem.doClick();
              break;
            case "Solve":
              menuName = "solve";
              menuItem.doClick();
              break;
            case "Quit":
              menuName = "quit";
              menuItem.doClick();
              break;
            default:
              // About is not clicked because it is a modal dialog.
              break;
          }
        }
      }
    }
  }

  /**
   * Compare the atom button event to the expected position in the list.
   * 
   * @param button atom button "pressed"
   */
  @Override
  public void atomButtonEvent(JButton button) {
    assertEquals(posIterator.next(), ((AtomJButton) button).getPosition());
  }

  /**
   * Compare the ray button event to the expected position in the list.
   * 
   * @param button ray button "pressed"
   */
  @Override
  public void rayButtonEvent(JButton button) {
    assertEquals(posIterator.next(), ((RayJButton) button).getPosition());
  }

  /**
   * Compare quit button with expected menu item name.
   */
  @Override
  public void quit() {
    assertEquals("quit", menuName);
  }

  /**
   * Compare newGame button with expected menu item name.
   */
  @Override
  public void newGame() {
    assertEquals("newGame", menuName);
  }

  /**
   * Compare solve button with expected menu item name.
   */
  @Override
  public void solve() {
    assertEquals("solve", menuName);
  }

  /**
   * Button data for sorting the X and Y locations to the right and down on the
   * grid.
   */
  private class ButtonData implements Comparable <ButtonData> {
    public JButton button;
    public int x, y;

    /**
     * Constructor sets the button data.
     * 
     * @param button button data
     */
    public ButtonData(JButton button) {
      this.button = button;
      x = button.getLocation().x;
      y = button.getLocation().y;
    }

    /**
     * Override to test for same button instance or X and Y positions.
     * 
     * @param obj button to test
     * @return true if instance or positions match
     */
    @Override
    public boolean equals(Object obj) {
      if (! (obj instanceof ButtonData)) {
        return false;
      }
      ButtonData data = (ButtonData) obj;
      if ( (data.x == x) && (data.y == y)) {
        return true;
      }
      return false;
    }

    /**
     * Override to compare X and Y positions.
     * 
     * @param data button data to compare
     * @return compare in column major order
     */
    @Override
    public int compareTo(ButtonData data) {
      int result = Integer.compare(y, data.y);
      if (result == 0) {
        result = Integer.compare(x, data.x);
      }
      return result;
    }
  }

  /**
   * Does nothing.
   */
  @Override
  public void help() {
  }
}
