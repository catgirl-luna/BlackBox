package blackBox;

/**
 * Class Model
 */
public class Model {

	//
	// Fields
	//

	/**
	 * Running score.
	 */
	private int score = 0;
	/**
	 * Atoms set by the game.
	 */
	private ArrayList atoms;
	/**
	 * Two-dimensional array of ray positions, start and end.
	 */
	private ArrayList userRays;
	/**
	 * Atoms set by the user.
	 */
	private ArrayList userAtoms;

	//
	// Constructors
	//
	public Model() {
	};

	//
	// Methods
	//

	//
	// Other methods
	//

	/**
	 * Increases the score and returns it.
	 * 
	 * @return int
	 * @param value
	 */
	public int increaseScore(int value) {
	}

	/**
	 * Gets the current score.
	 * 
	 * @return int
	 */
	public int getScore() {
	}

	/**
	 * Add a user ray on the grid.
	 * 
	 * @param pos
	 */
	public void addUserRay(blackBox.Position pos) {
	}

	/**
	 * Resets the score and clears the array lists of atoms and rays.
	 */
	public void newGame() {
	}

	/**
	 * @param pos
	 */
	public void setAtom(blackBox.Position pos) {
	}

	/**
	 * @param pos
	 */
	public void setUserAtoms(blackBox.Position pos) {
	}

	/**
	 * Iterator of user-placed atoms.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getUserAtoms() {
	}

	/**
	 * Gets the game atoms.
	 * 
	 * @return ArrayList
	 */
	public ArrayList getAtoms() {
	}

	/**
	 * @return ArrayList
	 */
	public ArrayList getUserRays() {
	}

}
