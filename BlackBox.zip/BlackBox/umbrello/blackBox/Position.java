package blackBox;


/**
 * Class Position
 */
public class Position {

    //
    // Fields
    //

    
    //
    // Constructors
    //
    public Position () { };
    
    //
    // Methods
    //


    //
    // Accessor methods
    //

    //
    // Other methods
    //

}
