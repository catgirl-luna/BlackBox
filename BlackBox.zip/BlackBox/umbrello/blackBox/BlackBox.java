package blackBox;

import java.util.*;


/**
 * Class BlackBox
 */
public class BlackBox {

    //
    // Fields
    //

    
    //
    // Constructors
    //
    public BlackBox () { };
    
    //
    // Methods
    //


    //
    // Accessor methods
    //

    //
    // Other methods
    //

    /**
     * @param        args
     */
    public static void main(ArrayList args)
    {
    }


}
