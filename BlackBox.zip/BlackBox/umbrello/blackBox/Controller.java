package blackBox;

import java.util.*;


/**
 * Class Controller
 */
public class Controller {

    //
    // Fields
    //

    
    //
    // Constructors
    //
    public Controller () { };
    
    //
    // Methods
    //


    //
    // Accessor methods
    //

    //
    // Other methods
    //

}
