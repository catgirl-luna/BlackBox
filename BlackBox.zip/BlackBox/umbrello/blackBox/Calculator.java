package blackBox;


/**
 * Class Calculator
 */
public class Calculator {

    //
    // Fields
    //

    private Boolean[][] atomGrid;
    
    //
    // Constructors
    //
    public Calculator () { };
    
    //
    // Methods
    //


    //
    // Accessor methods
    //

    /**
     * Set the value of atomGrid
     * @param newVar the new value of atomGrid
     */
    private void setAtomGrid (Boolean[][] newVar) {
        atomGrid = newVar;
    }

    /**
     * Get the value of atomGrid
     * @return the value of atomGrid
     */
    private Boolean[][] getAtomGrid () {
        return atomGrid;
    }

    //
    // Other methods
    //

    /**
     * Clears atoms and creates new atoms.
     * @return       ArrayList
     */
    public ArrayList createAtoms()
    {
    }


    /**
     * @param        pos
     */
    public void calculateRays(blackBox.Position pos)
    {
    }


}
