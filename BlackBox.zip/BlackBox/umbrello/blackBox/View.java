package blackBox;


/**
 * Class View
 */
public class View {

    //
    // Fields
    //

    
    //
    // Constructors
    //
    public View () { };
    
    //
    // Methods
    //


    //
    // Accessor methods
    //

    //
    // Other methods
    //

}
